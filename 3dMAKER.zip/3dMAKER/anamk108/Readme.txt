***********************************************
             Anaglyph Maker Ver1.08

      by Takashi Sekitani / www.stereoeye.jp
***********************************************

Thank you for downloading 'Anaglyph Maker'.

This program is a Freeware for Windows98/Me/NT/2000/XP to make 3D images.
'Anaglyph Maker' is a tool for making Anaglyph image for red-blue glasses, 
interleave image for 3D-LC shutter glasses and images for auto 3D-LCD
from your stereo photographs.

Anaglyph is 3D image that you can see with red-blue glasses.
You can get the red-blue glasses at the following websites.
        'Reel-3D' : http://www.stereoscopy.com/reel3d/anaglyph-glasses.html
 'Berezin Stereo' : http://www.berezin.com/3d/3dglasses.htm

Interleave image is 3D image that you can see with LC-shutter glasses 
such as VR-Surfer, i-glasses...
You can get the LC-shutter glasses at the following websites.
      'VR Surfer' : http://www.vrex.com/
      'i-glasses' : http://www.i-glasses.com/

---------------------------------------------------------------------------
*How to installation
  Expand 'anamk108.zip' and execute 'AnaMaker.exe'.

*Distribution
  Freely distributable

*How to use this program.
 1. Prepare for a pair of stereo photograph images.
    Let's take stereo photographs!
    If you would like to know about how to take stereo photograph, 
    please refer to my 3D web site: http://www.stereoeye.jp/ and 
    check the links at my website.
 2. Execute 'AnaMaker.exe'
 3. Push the 'Load Left Image' button to load the left image of the
    stereo photograph, and Push the 'Load Right Image' button to load
    the right image of the stereo photograph.
    This software can import BMP or JPEG format.
 4. Select 3D method from Gray-anaglyph, Color-anaglyph, Interleave...
 5. Push 'Make 3D image' button. Then, the 3D image will be displayed.
 6. Adjust vertical shift of the image for easy viewing with 'U,D'
    buttons, and adjust horizontal shift of the image for 3D depth
    with 'L,R' buttons. If you wear the red-blue glasses when adjusting,
    you will adjust very easy.
 7. Finally, push 'Save 3D image' button to save your 3D image.
    You can save BMP or JPEG format.
    If you want two images for parallel viewing or cross-eyed viewing or
    STEREO SCOPE(*1), click the radio button of '2 images(left & right)' 
    when saving images.

If you need more information, please visit my website.
And if you have any questions and comments, please send me your email.
Thank you.

*1 : STEREO SCOPE is a java applet by Andreas Petersik.
     Refer to his website. ( http://www.stereofoto.de/ )

*Problems
 If you use Windows 98/Me, this program may not handle big size image file 
over 64MByte that is about 4000 X 4000 pixels. If you would like to handle 
more than 4000 X 4000 pixels's images, please use Windows NT/2000/XP.

*Version history
Ver1.01 : First release
Ver1.02 : Add red-green & red-blue Anaglyph method
Ver1.05 : Debug some problems
Ver1.06 : Add save option (2 images by left & right)
          Add simple print menu
Ver1.07 : Debug some problems when saving JPEG format.
          Debug some problems when printing big images.
          Add auto view mode.
Ver1.08 : Add 3D-LCD method
          Add FULL SCREEN view
          Debug when loading B/W images.

----------------------------------------------------------
 Copyright (c) 2000-2004 by Takashi Sekitani / STEREOeYe

 Email: sekitani@stereoeye.jp
   URL: http://www.stereoeye.jp/
                                               April.2004
----------------------------------------------------------
